#!/usr/bin/env python3
import subprocess
import sys
import os



#print(len(sys.argv)-1)
#print(os.environ['HOME'])
#for variable_entorno,lol in os.environ.items():
#    print("Nombre: "+variable_entorno+"\tValor: " +lol)

#os.mkdir("Puta")
#for f in os.listdir("."):
#    print(f)

#os.rmdir('Puta')
#os.remove("prueba")

#os.renames('jaja.py', 'pruebas.py')

#fichero = open("prueba.txt", "w")

#for x in range (1,50,1):
#    fichero.write("klk manin\n")

#contenido = fichero.read(4) # lee los 4 primeros caracteres
#print(contenido)

#for contenido in fichero:
#    print("l-" +contenido) # va leyendo por lineas

#fichero.close()

import glob

'''busqueda = glob.glob("/bin/???e")
for i in busqueda:
    print(i)
print(busqueda)'''


#busqueda = subprocess.check_output("ls -l /home")
subprocess.run("tar -cvf comp.tar pruebas.py", shell=True)
print(subprocess)